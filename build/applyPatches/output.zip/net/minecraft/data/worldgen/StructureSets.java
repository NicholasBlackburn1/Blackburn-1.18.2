package net.minecraft.data.worldgen;

import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.Vec3i;
import net.minecraft.data.BuiltinRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.levelgen.feature.ConfiguredStructureFeature;
import net.minecraft.world.level.levelgen.structure.BuiltinStructureSets;
import net.minecraft.world.level.levelgen.structure.StructureSet;
import net.minecraft.world.level.levelgen.structure.placement.ConcentricRingsStructurePlacement;
import net.minecraft.world.level.levelgen.structure.placement.RandomSpreadStructurePlacement;
import net.minecraft.world.level.levelgen.structure.placement.RandomSpreadType;
import net.minecraft.world.level.levelgen.structure.placement.StructurePlacement;

public interface StructureSets {
   Holder<StructureSet> f_211109_ = m_211128_(BuiltinStructureSets.f_209820_, new StructureSet(List.of(StructureSet.m_210015_(StructureFeatures.f_127258_), StructureSet.m_210015_(StructureFeatures.f_127259_), StructureSet.m_210015_(StructureFeatures.f_127260_), StructureSet.m_210015_(StructureFeatures.f_127261_), StructureSet.m_210015_(StructureFeatures.f_127262_)), new RandomSpreadStructurePlacement(34, 8, RandomSpreadType.LINEAR, 10387312)));
   Holder<StructureSet> f_211110_ = m_211131_(BuiltinStructureSets.f_209821_, StructureFeatures.f_127244_, new RandomSpreadStructurePlacement(32, 8, RandomSpreadType.LINEAR, 14357617));
   Holder<StructureSet> f_211111_ = m_211131_(BuiltinStructureSets.f_209822_, StructureFeatures.f_127245_, new RandomSpreadStructurePlacement(32, 8, RandomSpreadType.LINEAR, 14357618));
   Holder<StructureSet> f_211112_ = m_211131_(BuiltinStructureSets.f_209823_, StructureFeatures.f_127243_, new RandomSpreadStructurePlacement(32, 8, RandomSpreadType.LINEAR, 14357619));
   Holder<StructureSet> f_211113_ = m_211131_(BuiltinStructureSets.f_209824_, StructureFeatures.f_127248_, new RandomSpreadStructurePlacement(32, 8, RandomSpreadType.LINEAR, 14357620));
   Holder<StructureSet> f_211114_ = m_211131_(BuiltinStructureSets.f_209825_, StructureFeatures.f_127239_, new RandomSpreadStructurePlacement(32, 8, RandomSpreadType.LINEAR, 165745296));
   Holder<StructureSet> f_211115_ = m_211131_(BuiltinStructureSets.f_209826_, StructureFeatures.f_127250_, new RandomSpreadStructurePlacement(32, 5, RandomSpreadType.TRIANGULAR, 10387313));
   Holder<StructureSet> f_211116_ = m_211131_(BuiltinStructureSets.f_209827_, StructureFeatures.f_127242_, new RandomSpreadStructurePlacement(80, 20, RandomSpreadType.TRIANGULAR, 10387319));
   Holder<StructureSet> f_211117_ = m_211131_(BuiltinStructureSets.f_209828_, StructureFeatures.f_127256_, new RandomSpreadStructurePlacement(1, 0, RandomSpreadType.LINEAR, 0, new Vec3i(9, 0, 9)));
   Holder<StructureSet> f_211118_ = m_211128_(BuiltinStructureSets.f_209829_, new StructureSet(List.of(StructureSet.m_210015_(StructureFeatures.f_127240_), StructureSet.m_210015_(StructureFeatures.f_127241_)), new RandomSpreadStructurePlacement(1, 0, RandomSpreadType.LINEAR, 0)));
   Holder<StructureSet> f_211119_ = m_211128_(BuiltinStructureSets.f_209830_, new StructureSet(List.of(StructureSet.m_210015_(StructureFeatures.f_127263_), StructureSet.m_210015_(StructureFeatures.f_127264_), StructureSet.m_210015_(StructureFeatures.f_127234_), StructureSet.m_210015_(StructureFeatures.f_127235_), StructureSet.m_210015_(StructureFeatures.f_127236_), StructureSet.m_210015_(StructureFeatures.f_127237_), StructureSet.m_210015_(StructureFeatures.f_127238_)), new RandomSpreadStructurePlacement(40, 15, RandomSpreadType.LINEAR, 34222645)));
   Holder<StructureSet> f_211120_ = m_211128_(BuiltinStructureSets.f_209831_, new StructureSet(List.of(StructureSet.m_210015_(StructureFeatures.f_127246_), StructureSet.m_210015_(StructureFeatures.f_194755_)), new RandomSpreadStructurePlacement(24, 4, RandomSpreadType.LINEAR, 165745295)));
   Holder<StructureSet> f_211121_ = m_211128_(BuiltinStructureSets.f_209832_, new StructureSet(List.of(StructureSet.m_210015_(StructureFeatures.f_127251_), StructureSet.m_210015_(StructureFeatures.f_127252_)), new RandomSpreadStructurePlacement(20, 8, RandomSpreadType.LINEAR, 14357621)));
   Holder<StructureSet> f_211122_ = m_211128_(BuiltinStructureSets.f_209833_, new StructureSet(List.of(StructureSet.m_210017_(StructureFeatures.f_211105_, 2), StructureSet.m_210017_(StructureFeatures.f_127257_, 3)), new RandomSpreadStructurePlacement(27, 4, RandomSpreadType.LINEAR, 30084232)));
   Holder<StructureSet> f_211123_ = m_211131_(BuiltinStructureSets.f_209834_, StructureFeatures.f_127254_, new RandomSpreadStructurePlacement(2, 1, RandomSpreadType.LINEAR, 14357921));
   Holder<StructureSet> f_211124_ = m_211131_(BuiltinStructureSets.f_209835_, StructureFeatures.f_127255_, new RandomSpreadStructurePlacement(20, 11, RandomSpreadType.TRIANGULAR, 10387313));
   Holder<StructureSet> f_211125_ = m_211131_(BuiltinStructureSets.f_209836_, StructureFeatures.f_127249_, new ConcentricRingsStructurePlacement(32, 3, 128));

   static Holder<StructureSet> m_211127_() {
      return BuiltinRegistries.f_211084_.m_203611_().iterator().next();
   }

   static Holder<StructureSet> m_211128_(ResourceKey<StructureSet> p_211129_, StructureSet p_211130_) {
      return BuiltinRegistries.m_206384_(BuiltinRegistries.f_211084_, p_211129_, p_211130_);
   }

   static Holder<StructureSet> m_211131_(ResourceKey<StructureSet> p_211132_, Holder<ConfiguredStructureFeature<?, ?>> p_211133_, StructurePlacement p_211134_) {
      return m_211128_(p_211132_, new StructureSet(p_211133_, p_211134_));
   }
}