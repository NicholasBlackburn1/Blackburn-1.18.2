package net.minecraft.world.level.levelgen;

import com.google.common.annotations.VisibleForTesting;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

public interface PositionalRandomFactory {
   default RandomSource m_189314_(BlockPos p_189315_) {
      return this.m_183161_(p_189315_.m_123341_(), p_189315_.m_123342_(), p_189315_.m_123343_());
   }

   default RandomSource m_189318_(ResourceLocation p_189319_) {
      return this.m_183211_(p_189319_.toString());
   }

   RandomSource m_183211_(String p_189316_);

   RandomSource m_183161_(int p_189311_, int p_189312_, int p_189313_);

   @VisibleForTesting
   void m_183502_(StringBuilder p_189317_);
}