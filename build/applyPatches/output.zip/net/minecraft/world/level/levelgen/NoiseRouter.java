package net.minecraft.world.level.levelgen;

import java.util.List;
import net.minecraft.world.level.biome.Climate;

public record NoiseRouter(DensityFunction f_209378_, DensityFunction f_209379_, DensityFunction f_209380_, DensityFunction f_209381_, PositionalRandomFactory f_209382_, PositionalRandomFactory f_209383_, DensityFunction f_209384_, DensityFunction f_209385_, DensityFunction f_209386_, DensityFunction f_209387_, DensityFunction f_209388_, DensityFunction f_209389_, DensityFunction f_209390_, DensityFunction f_209391_, DensityFunction f_209392_, DensityFunction f_209393_, DensityFunction f_209394_, List<Climate.ParameterPoint> f_209395_) {
}