package net.minecraft.world.level.levelgen.structure.pieces;

import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.core.Holder;
import net.minecraft.core.QuartPos;
import net.minecraft.core.RegistryAccess;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.configurations.FeatureConfiguration;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureManager;

@FunctionalInterface
public interface PieceGeneratorSupplier<C extends FeatureConfiguration> {
   Optional<PieceGenerator<C>> m_197347_(PieceGeneratorSupplier.Context<C> p_197348_);

   static <C extends FeatureConfiguration> PieceGeneratorSupplier<C> m_197349_(Predicate<PieceGeneratorSupplier.Context<C>> p_197350_, PieceGenerator<C> p_197351_) {
      Optional<PieceGenerator<C>> optional = Optional.of(p_197351_);
      return (p_197344_) -> {
         return p_197350_.test(p_197344_) ? optional : Optional.empty();
      };
   }

   static <C extends FeatureConfiguration> Predicate<PieceGeneratorSupplier.Context<C>> m_197345_(Heightmap.Types p_197346_) {
      return (p_197340_) -> {
         return p_197340_.m_197380_(p_197346_);
      };
   }

   public static record Context<C extends FeatureConfiguration>(ChunkGenerator f_197352_, BiomeSource f_197353_, long f_197354_, ChunkPos f_197355_, C f_197356_, LevelHeightAccessor f_197357_, Predicate<Holder<Biome>> f_197358_, StructureManager f_197359_, RegistryAccess f_197360_) {
      public boolean m_197380_(Heightmap.Types p_197381_) {
         int i = this.f_197355_.m_151390_();
         int j = this.f_197355_.m_151393_();
         int k = this.f_197352_.m_156179_(i, j, p_197381_, this.f_197357_);
         Holder<Biome> holder = this.f_197352_.m_203495_(QuartPos.m_175400_(i), QuartPos.m_175400_(k), QuartPos.m_175400_(j));
         return this.f_197358_.test(holder);
      }

      public int[] m_197375_(int p_197376_, int p_197377_, int p_197378_, int p_197379_) {
         return new int[]{this.f_197352_.m_156179_(p_197376_, p_197378_, Heightmap.Types.WORLD_SURFACE_WG, this.f_197357_), this.f_197352_.m_156179_(p_197376_, p_197378_ + p_197379_, Heightmap.Types.WORLD_SURFACE_WG, this.f_197357_), this.f_197352_.m_156179_(p_197376_ + p_197377_, p_197378_, Heightmap.Types.WORLD_SURFACE_WG, this.f_197357_), this.f_197352_.m_156179_(p_197376_ + p_197377_, p_197378_ + p_197379_, Heightmap.Types.WORLD_SURFACE_WG, this.f_197357_)};
      }

      public int m_197372_(int p_197373_, int p_197374_) {
         int i = this.f_197355_.m_45604_();
         int j = this.f_197355_.m_45605_();
         int[] aint = this.m_197375_(i, p_197373_, j, p_197374_);
         return Math.min(Math.min(aint[0], aint[1]), Math.min(aint[2], aint[3]));
      }
   }
}