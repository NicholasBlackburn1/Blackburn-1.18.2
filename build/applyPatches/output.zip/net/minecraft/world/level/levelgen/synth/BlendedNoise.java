package net.minecraft.world.level.levelgen.synth;

import com.google.common.annotations.VisibleForTesting;
import com.mojang.serialization.Codec;
import java.util.stream.IntStream;
import net.minecraft.util.Mth;
import net.minecraft.world.level.levelgen.DensityFunction;
import net.minecraft.world.level.levelgen.NoiseSamplingSettings;
import net.minecraft.world.level.levelgen.RandomSource;
import net.minecraft.world.level.levelgen.XoroshiroRandomSource;

public class BlendedNoise implements DensityFunction.SimpleFunction {
   public static final BlendedNoise f_210615_ = new BlendedNoise(new XoroshiroRandomSource(0L), new NoiseSamplingSettings(1.0D, 1.0D, 80.0D, 160.0D), 4, 8);
   public static final Codec<BlendedNoise> f_210616_ = Codec.unit(f_210615_);
   private final PerlinNoise f_164288_;
   private final PerlinNoise f_164289_;
   private final PerlinNoise f_164290_;
   private final double f_192799_;
   private final double f_192800_;
   private final double f_192801_;
   private final double f_192802_;
   private final int f_192803_;
   private final int f_192804_;
   private final double f_210617_;

   private BlendedNoise(PerlinNoise p_192811_, PerlinNoise p_192812_, PerlinNoise p_192813_, NoiseSamplingSettings p_192814_, int p_192815_, int p_192816_) {
      this.f_164288_ = p_192811_;
      this.f_164289_ = p_192812_;
      this.f_164290_ = p_192813_;
      this.f_192799_ = 684.412D * p_192814_.f_64491_();
      this.f_192800_ = 684.412D * p_192814_.f_64492_();
      this.f_192801_ = this.f_192799_ / p_192814_.f_64493_();
      this.f_192802_ = this.f_192800_ / p_192814_.f_64494_();
      this.f_192803_ = p_192815_;
      this.f_192804_ = p_192816_;
      this.f_210617_ = p_192811_.m_210643_(this.f_192800_);
   }

   public BlendedNoise(RandomSource p_192806_, NoiseSamplingSettings p_192807_, int p_192808_, int p_192809_) {
      this(PerlinNoise.m_192885_(p_192806_, IntStream.rangeClosed(-15, 0)), PerlinNoise.m_192885_(p_192806_, IntStream.rangeClosed(-15, 0)), PerlinNoise.m_192885_(p_192806_, IntStream.rangeClosed(-7, 0)), p_192807_, p_192808_, p_192809_);
   }

   public double m_207386_(DensityFunction.FunctionContext p_210621_) {
      int i = Math.floorDiv(p_210621_.m_207115_(), this.f_192803_);
      int j = Math.floorDiv(p_210621_.m_207114_(), this.f_192804_);
      int k = Math.floorDiv(p_210621_.m_207113_(), this.f_192803_);
      double d0 = 0.0D;
      double d1 = 0.0D;
      double d2 = 0.0D;
      boolean flag = true;
      double d3 = 1.0D;

      for(int l = 0; l < 8; ++l) {
         ImprovedNoise improvednoise = this.f_164290_.m_75424_(l);
         if (improvednoise != null) {
            d2 += improvednoise.m_75327_(PerlinNoise.m_75406_((double)i * this.f_192801_ * d3), PerlinNoise.m_75406_((double)j * this.f_192802_ * d3), PerlinNoise.m_75406_((double)k * this.f_192801_ * d3), this.f_192802_ * d3, (double)j * this.f_192802_ * d3) / d3;
         }

         d3 /= 2.0D;
      }

      double d8 = (d2 / 10.0D + 1.0D) / 2.0D;
      boolean flag1 = d8 >= 1.0D;
      boolean flag2 = d8 <= 0.0D;
      d3 = 1.0D;

      for(int i1 = 0; i1 < 16; ++i1) {
         double d4 = PerlinNoise.m_75406_((double)i * this.f_192799_ * d3);
         double d5 = PerlinNoise.m_75406_((double)j * this.f_192800_ * d3);
         double d6 = PerlinNoise.m_75406_((double)k * this.f_192799_ * d3);
         double d7 = this.f_192800_ * d3;
         if (!flag1) {
            ImprovedNoise improvednoise1 = this.f_164288_.m_75424_(i1);
            if (improvednoise1 != null) {
               d0 += improvednoise1.m_75327_(d4, d5, d6, d7, (double)j * d7) / d3;
            }
         }

         if (!flag2) {
            ImprovedNoise improvednoise2 = this.f_164289_.m_75424_(i1);
            if (improvednoise2 != null) {
               d1 += improvednoise2.m_75327_(d4, d5, d6, d7, (double)j * d7) / d3;
            }
         }

         d3 /= 2.0D;
      }

      return Mth.m_14085_(d0 / 512.0D, d1 / 512.0D, d8) / 128.0D;
   }

   public double m_207402_() {
      return -this.m_207401_();
   }

   public double m_207401_() {
      return this.f_210617_;
   }

   @VisibleForTesting
   public void m_192817_(StringBuilder p_192818_) {
      p_192818_.append("BlendedNoise{minLimitNoise=");
      this.f_164288_.m_192890_(p_192818_);
      p_192818_.append(", maxLimitNoise=");
      this.f_164289_.m_192890_(p_192818_);
      p_192818_.append(", mainNoise=");
      this.f_164290_.m_192890_(p_192818_);
      p_192818_.append(String.format(", xzScale=%.3f, yScale=%.3f, xzMainScale=%.3f, yMainScale=%.3f, cellWidth=%d, cellHeight=%d", this.f_192799_, this.f_192800_, this.f_192801_, this.f_192802_, this.f_192803_, this.f_192804_)).append('}');
   }

   public Codec<? extends DensityFunction> m_207500_() {
      return f_210616_;
   }
}