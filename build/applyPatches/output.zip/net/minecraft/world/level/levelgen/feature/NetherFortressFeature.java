package net.minecraft.world.level.levelgen.feature;

import com.mojang.serialization.Codec;
import java.util.List;
import net.minecraft.core.QuartPos;
import net.minecraft.util.random.WeightedRandomList;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.levelgen.structure.NetherBridgePieces;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.PieceGenerator;
import net.minecraft.world.level.levelgen.structure.pieces.PieceGeneratorSupplier;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePiecesBuilder;

public class NetherFortressFeature extends StructureFeature<NoneFeatureConfiguration> {
   public static final WeightedRandomList<MobSpawnSettings.SpawnerData> f_66381_ = WeightedRandomList.m_146330_(new MobSpawnSettings.SpawnerData(EntityType.f_20551_, 10, 2, 3), new MobSpawnSettings.SpawnerData(EntityType.f_20531_, 5, 4, 4), new MobSpawnSettings.SpawnerData(EntityType.f_20497_, 8, 5, 5), new MobSpawnSettings.SpawnerData(EntityType.f_20524_, 2, 5, 5), new MobSpawnSettings.SpawnerData(EntityType.f_20468_, 3, 4, 4));

   public NetherFortressFeature(Codec<NoneFeatureConfiguration> p_66384_) {
      super(p_66384_, PieceGeneratorSupplier.m_197349_(NetherFortressFeature::m_197126_, NetherFortressFeature::m_197128_));
   }

   private static boolean m_197126_(PieceGeneratorSupplier.Context<NoneFeatureConfiguration> p_197127_) {
      return p_197127_.f_197358_().test(p_197127_.f_197352_().m_203495_(QuartPos.m_175400_(p_197127_.f_197355_().m_151390_()), QuartPos.m_175400_(64), QuartPos.m_175400_(p_197127_.f_197355_().m_151393_())));
   }

   private static void m_197128_(StructurePiecesBuilder p_197129_, PieceGenerator.Context<NoneFeatureConfiguration> p_197130_) {
      NetherBridgePieces.StartPiece netherbridgepieces$startpiece = new NetherBridgePieces.StartPiece(p_197130_.f_192708_(), p_197130_.f_192705_().m_151382_(2), p_197130_.f_192705_().m_151391_(2));
      p_197129_.m_142679_(netherbridgepieces$startpiece);
      netherbridgepieces$startpiece.m_142537_(netherbridgepieces$startpiece, p_197129_, p_197130_.f_192708_());
      List<StructurePiece> list = netherbridgepieces$startpiece.f_72022_;

      while(!list.isEmpty()) {
         int i = p_197130_.f_192708_().nextInt(list.size());
         StructurePiece structurepiece = list.remove(i);
         structurepiece.m_142537_(netherbridgepieces$startpiece, p_197129_, p_197130_.f_192708_());
      }

      p_197129_.m_192792_(p_197130_.f_192708_(), 48, 70);
   }
}