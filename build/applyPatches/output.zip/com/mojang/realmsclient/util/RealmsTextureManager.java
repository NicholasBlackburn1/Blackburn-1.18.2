package com.mojang.realmsclient.util;

import com.google.common.base.Suppliers;
import com.google.common.collect.Maps;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.mojang.authlib.minecraft.MinecraftProfileTexture.Type;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.TextureUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import com.mojang.util.UUIDTypeAdapter;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.IntBuffer;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.lwjgl.BufferUtils;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class RealmsTextureManager {
   private static final Map<String, RealmsTextureManager.RealmsTexture> f_90178_ = Maps.newHashMap();
   static final Map<String, Boolean> f_90179_ = Maps.newHashMap();
   static final Map<String, String> f_90180_ = Maps.newHashMap();
   static final Logger f_90181_ = LogUtils.getLogger();
   private static final ResourceLocation f_90182_ = new ResourceLocation("textures/gui/presets/isles.png");

   public static void m_90190_(String p_90191_, @Nullable String p_90192_) {
      if (p_90192_ == null) {
         RenderSystem.m_157456_(0, f_90182_);
      } else {
         int i = m_90196_(p_90191_, p_90192_);
         RenderSystem.m_157453_(0, i);
      }
   }

   public static void m_90187_(String p_90188_, Runnable p_90189_) {
      m_90185_(p_90188_);
      p_90189_.run();
   }

   private static void m_90193_(UUID p_90194_) {
      RenderSystem.m_157456_(0, DefaultPlayerSkin.m_118627_(p_90194_));
   }

   private static void m_90185_(final String p_90186_) {
      UUID uuid = UUIDTypeAdapter.fromString(p_90186_);
      if (f_90178_.containsKey(p_90186_)) {
         int j = (f_90178_.get(p_90186_)).f_90206_;
         RenderSystem.m_157453_(0, j);
      } else if (f_90179_.containsKey(p_90186_)) {
         if (!f_90179_.get(p_90186_)) {
            m_90193_(uuid);
         } else if (f_90180_.containsKey(p_90186_)) {
            int i = m_90196_(p_90186_, f_90180_.get(p_90186_));
            RenderSystem.m_157453_(0, i);
         } else {
            m_90193_(uuid);
         }

      } else {
         f_90179_.put(p_90186_, false);
         m_90193_(uuid);
         Thread thread = new Thread("Realms Texture Downloader") {
            public void run() {
               Map<Type, MinecraftProfileTexture> map = RealmsUtil.m_90225_(p_90186_);
               if (map.containsKey(Type.SKIN)) {
                  MinecraftProfileTexture minecraftprofiletexture = map.get(Type.SKIN);
                  String s = minecraftprofiletexture.getUrl();
                  HttpURLConnection httpurlconnection = null;
                  RealmsTextureManager.f_90181_.debug("Downloading http texture from {}", (Object)s);

                  try {
                     httpurlconnection = (HttpURLConnection)(new URL(s)).openConnection(Minecraft.m_91087_().m_91096_());
                     httpurlconnection.setDoInput(true);
                     httpurlconnection.setDoOutput(false);
                     httpurlconnection.connect();
                     if (httpurlconnection.getResponseCode() / 100 == 2) {
                        BufferedImage bufferedimage;
                        try {
                           bufferedimage = ImageIO.read(httpurlconnection.getInputStream());
                        } catch (Exception exception) {
                           RealmsTextureManager.f_90179_.remove(p_90186_);
                           return;
                        } finally {
                           IOUtils.closeQuietly(httpurlconnection.getInputStream());
                        }

                        bufferedimage = (new SkinProcessor()).m_90241_(bufferedimage);
                        ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
                        ImageIO.write(bufferedimage, "png", bytearrayoutputstream);
                        RealmsTextureManager.f_90180_.put(p_90186_, (new Base64()).encodeToString(bytearrayoutputstream.toByteArray()));
                        RealmsTextureManager.f_90179_.put(p_90186_, true);
                        return;
                     }

                     RealmsTextureManager.f_90179_.remove(p_90186_);
                  } catch (Exception exception1) {
                     RealmsTextureManager.f_90181_.error("Couldn't download http texture", (Throwable)exception1);
                     RealmsTextureManager.f_90179_.remove(p_90186_);
                     return;
                  } finally {
                     if (httpurlconnection != null) {
                        httpurlconnection.disconnect();
                     }

                  }

               } else {
                  RealmsTextureManager.f_90179_.put(p_90186_, true);
               }
            }
         };
         thread.setDaemon(true);
         thread.start();
      }
   }

   private static int m_90196_(String p_90197_, String p_90198_) {
      RealmsTextureManager.RealmsTexture realmstexturemanager$realmstexture = f_90178_.get(p_90197_);
      if (realmstexturemanager$realmstexture != null && realmstexturemanager$realmstexture.f_90205_.equals(p_90198_)) {
         return realmstexturemanager$realmstexture.f_90206_;
      } else {
         int i;
         if (realmstexturemanager$realmstexture != null) {
            i = realmstexturemanager$realmstexture.f_90206_;
         } else {
            i = GlStateManager.m_84111_();
         }

         RealmsTextureManager.TextureData realmstexturemanager$texturedata = RealmsTextureManager.TextureData.m_193528_(p_90198_);
         RenderSystem.m_69388_(33984);
         RenderSystem.m_157184_(i);
         TextureUtil.m_85305_(realmstexturemanager$texturedata.f_193520_, realmstexturemanager$texturedata.f_193518_, realmstexturemanager$texturedata.f_193519_);
         f_90178_.put(p_90197_, new RealmsTextureManager.RealmsTexture(p_90198_, i));
         return i;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class RealmsTexture {
      final String f_90205_;
      final int f_90206_;

      public RealmsTexture(String p_90208_, int p_90209_) {
         this.f_90205_ = p_90208_;
         this.f_90206_ = p_90209_;
      }
   }

   @OnlyIn(Dist.CLIENT)
   static class TextureData {
      final int f_193518_;
      final int f_193519_;
      final IntBuffer f_193520_;
      private static final Supplier<RealmsTextureManager.TextureData> f_193521_ = Suppliers.memoize(() -> {
         int i = 16;
         int j = 16;
         IntBuffer intbuffer = BufferUtils.createIntBuffer(256);
         int k = -16777216;
         int l = -524040;

         for(int i1 = 0; i1 < 16; ++i1) {
            for(int j1 = 0; j1 < 16; ++j1) {
               if (i1 < 8 ^ j1 < 8) {
                  intbuffer.put(j1 + i1 * 16, -524040);
               } else {
                  intbuffer.put(j1 + i1 * 16, -16777216);
               }
            }
         }

         return new RealmsTextureManager.TextureData(16, 16, intbuffer);
      });

      private TextureData(int p_193524_, int p_193525_, IntBuffer p_193526_) {
         this.f_193518_ = p_193524_;
         this.f_193519_ = p_193525_;
         this.f_193520_ = p_193526_;
      }

      public static RealmsTextureManager.TextureData m_193528_(String p_193529_) {
         try {
            InputStream inputstream = new ByteArrayInputStream((new Base64()).decode(p_193529_));
            BufferedImage bufferedimage = ImageIO.read(inputstream);
            if (bufferedimage != null) {
               int i = bufferedimage.getWidth();
               int j = bufferedimage.getHeight();
               int[] aint = new int[i * j];
               bufferedimage.getRGB(0, 0, i, j, aint, 0, i);
               IntBuffer intbuffer = BufferUtils.createIntBuffer(i * j);
               intbuffer.put(aint);
               intbuffer.flip();
               return new RealmsTextureManager.TextureData(i, j, intbuffer);
            }

            RealmsTextureManager.f_90181_.warn("Unknown image format: {}", (Object)p_193529_);
         } catch (IOException ioexception) {
            RealmsTextureManager.f_90181_.warn("Failed to load world image: {}", p_193529_, ioexception);
         }

         return f_193521_.get();
      }
   }
}